#include "robotSetup.h"
#include "autoSelect/selection.h"

// Drive motor definitions
int kS= 80; // <--- Put the percentage of maximum speed you want here, ie. 75 -> 75%, 50 -> 50%, etc. ONLY CHANGE THE NUMBER!

float kickerSpeedPercentage = kS * 0.01;

pros::Motor LDF (LeftDriveFront, true);
pros::Motor LDB (LeftDriveBottom, true);
pros::Motor LDT (LeftDriveTop, false);
pros::Motor RDF (RightDriveFront, false);
pros::Motor RDB (RightDriveBottom, false);
pros::Motor RDT (RightDriveTop, true);

//left and right side definitions
pros::Motor_Group driveleft ( {LDF , LDB , LDT});
pros::Motor_Group driveright ( {RDF , RDB , RDT});

//odometry definitions
pros::Imu imu(IMUPort);


pros::Controller master(pros::E_CONTROLLER_MASTER);


lemlib::Drivetrain drivetrain
{ 
    &driveleft,
    &driveright,
    10.125,
    4.125,
    300,
    5

};

lemlib::OdomSensors odomsensors
{
    	nullptr,
		nullptr, /*No Tracking Wheel*/
		nullptr, /*No Tracking Wheel*/
		nullptr, /*No Tracking Wheel*/
		&imu /*Inertial Sensor*/
};

	lemlib::ControllerSettings lateralController
	{
		17, //16, // kP
		0, //1, //kI
		50, //72, // kD
	    0, //1, windupRange
		1, // smallErrorRange
		400, // smallErrorTimeout
		3, // largeErrorRange
		1000, // largeErrorTimeout
		20 // Slew Rate
	};

	lemlib::ControllerSettings angularController
	{
		2.6, // kP
		0, //kI
		20.2, // kD
		0, //windupRange
		1, // smallErrorRange 
		400, // smallErrorTimeout 
		3, // largeErrorRange 
		1000, // largeErrorTimeout 
		10// Slew Rate
	};

//chassis auton constructor 
lemlib::Chassis chassis( drivetrain , lateralController, angularController, odomsensors );

//pistons
pros::ADIDigitalOut wings(WingPort);
pros::ADIDigitalOut liftup(LiftUpPort);
pros::ADIDigitalOut liftdown(LiftDownPort);
pros::ADIDigitalOut hang(HangPort);
pros::Motor Intake(IntakePort,false);
pros::Motor Kicker(KickerPort,false);
pros::Motor Flywheel(fwport, blueCart, true);


void on_center_button()
{
	static bool pressed = false;
	pressed = !pressed;
	if (pressed)
	{
		pros::lcd::set_text(2, "I was pressed!");
	}
	else
	{
		pros::lcd::clear_line(2);
	}
}

void screen()
{
	while (true)
	{
		/*lemlib::Pose pose = chassis.getPose();			// get the current position of the robot
		pros::lcd::print(0, "x: %f", pose.x);			// print the x position
		pros::lcd::print(1, "y: %f", pose.y);			// print the y position
		pros::lcd::print(2, "heading: %f", pose.theta); // print the heading
		pros::delay(10);*/
	}
}
void initialize()
{
	pros::lcd::initialize();	   // initialize brain screen
	chassis.calibrate();		   // calibrate the chassis
	//pros::Task screenTask(screen);  //create a task to print the position to the screen
	selector::init();
}
void disabled() {}
void competition_initialize() {}
ASSET(safefourball1_txt);
ASSET(sixball1_txt);
ASSET(sixball2_txt);
ASSET(sixball3_txt);
ASSET(sixball4_txt);
ASSET(sixball5_txt);
//Skills Routes
ASSET(skills1_txt);
ASSET(skills2_txt);
ASSET(skills3_txt);

void SkillsStartRoute(){
	Intake.move_voltage(12000);
	pros::delay(300);
	Intake.move_voltage(0);
	chassis.setPose(-50,-54.5,135);
	//first push of alliance triballs
	chassis.moveToPose(-57,-20,180,2000,{.forwards = false,.chasePower = 8,.lead = 0.4,.minSpeed = 80});
	chassis.waitUntilDone();


	//aim for shooting
	pros::delay(100);
	chassis.setPose(-62,-30,180);
	chassis.moveToPoint(-62,-43,10000);
	chassis.turnTo(47,-5,800);
	chassis.moveToPoint(-63.5,-46,1000,false);
	chassis.waitUntilDone();
	wings.set_value(1);
	
	
}
void autonomous()
{
if(selector::auton == closeSideAuton){
	chassis.setPose(-48,-56,315);
	chassis.moveToPoint(-58,-46.5,2000);
	chassis.waitUntilDone();
	wings.set_value(1);
	chassis.moveToPoint(-49,-55,2000,false);
	chassis.waitUntilDone();
	wings.set_value(0);
	pros::delay(100);
	chassis.moveToPoint(-43,-61,2000,false);
	chassis.turnTo(-100,-61,1000);
	chassis.moveToPoint(-8,-61.5,2000,false);
	chassis.waitUntilDone();
	wings.set_value(1);
	chassis.turnTo(-50,-45,2000);
	liftup.set_value(1);



}
if(selector::auton == elimsFarSideAuton){
chassis.setPose(11,-59, 270 );
pros::delay(100);
Intake.move_voltage(12000);
chassis.moveToPoint(8, -59, 400, true, 40);
chassis.moveToPoint(11,-59,200,false,40);
chassis.follow( sixball1_txt , 15 ,1500,false);
chassis.waitUntil(65);
chassis.cancelMotion();
chassis.moveToPoint(60,90,400,false);
chassis.cancelMotion();

pros::delay(100);
chassis.turnTo(60,-90,400);
chassis.moveToPoint(60,-33,1000);
chassis.moveToPoint(60,90,400,false);
chassis.moveToPoint(64,-35,400);
chassis.turnTo(60.5,90,1000);
chassis.waitUntilDone();
Intake.move_voltage(-12000);
chassis.moveToPoint(60.5,90,600);
chassis.setPose(60.5,-24.5,0);

chassis.moveToPoint(60.5,-20,800,false,80);
chassis.turnTo(-46,15,800,true,80);
Intake.move_voltage(12000);
chassis.moveToPoint(-46,15,1000);
chassis.waitUntil(47);
chassis.cancelMotion();
chassis.turnTo(45,14,1000);
chassis.waitUntilDone();
Intake.move_voltage(-12000);
pros::delay(500);
chassis.turnTo(-30,90,1000);
Intake.move_voltage(12000);

chassis.moveToPoint(-20,90,1000);
chassis.waitUntil(10);
chassis.cancelMotion();
pros::delay(200);
chassis.turnTo(90,15,1000,false);
chassis.waitUntilDone();
wings.set_value(1);
chassis.moveToPoint(90,15,800,false);
chassis.waitUntilDone();
chassis.moveToPoint(30,15,300);
wings.set_value(0);
chassis.turnTo(90,15,400);
chassis.waitUntilDone();
chassis.moveToPoint(90,15,400);
Intake.move_voltage(-12000);
chassis.moveToPoint(-90,15,1000, false);

}
if(selector::auton == matchFarSideAuton){
	chassis.setPose(51,-49,0);
	chassis.turnTo(63,-33,400);
	chassis.moveToPose(59,-23,0,2000,{true, 15, 0, 80, 127}, true);
	chassis.waitUntil(8);
	Intake.move_voltage(-12000);
	chassis.moveToPoint(59,-35,500,false);
	chassis.waitUntil(5);
	chassis.cancelMotion();
	chassis.moveToPoint(59,-23,500);
	chassis.waitUntil(10);
	chassis.cancelMotion();

	//last 3 

chassis.follow(sixball2_txt, 20 ,10000,false);
chassis.follow(sixball3_txt, 15, 10000);
chassis.waitUntil(15);
Intake.move_voltage(12000);

chassis.turnTo(14,-14,1000,true,60);
chassis.waitUntil(300);
Intake.move_voltage(0);
chassis.follow(sixball4_txt,15,10000);
//score 4th triball
chassis.moveToPoint(43,-13,1000);
Intake.move_voltage(-12000);
//score 5th and 6th triball
chassis.follow(sixball5_txt, 15,4000,false);
chassis.waitUntil(30);
chassis.cancelMotion();
chassis.moveToPoint(5,0,3000);
chassis.waitUntil(5);
Intake.move_voltage(12000);
chassis.moveToPoint(8.5,-5,2000,false,60);

chassis.turnTo(-30,-9,1000,true,60);
wings.set_value(1);
chassis.moveToPoint(40,-5,3000,false,127);
chassis.waitUntil(5);
Intake.move_voltage(0);

chassis.moveToPoint(25,-5,1000);
chassis.waitUntil(7);
chassis.cancelMotion();
chassis.turnTo(50,-5,500,true, 60);
chassis.moveToPoint(55,-5,500);
}
if(selector::auton == skillsAuton){
	SkillsStartRoute();
	pros::delay(200);
	wings.set_value(1);
	Kicker.move_voltage(9200);
	pros::delay(23000);
	Kicker.move_voltage(0);
	wings.set_value(0);
	pros::delay(400);
	
	//go over barrier
	chassis.turnTo(90,-42,500);
	chassis.setPose(-61,-35,90);
	chassis.moveToPoint(-15,-35,10000);
	chassis.turnTo(90,-53,1000);
	Intake.move_voltage(-12000);

	chassis.setPose(-17,-35,90);
	chassis.moveToPoint(23,-38,2000);
	chassis.moveToPoint(-10,-35,1000,false,50);
	pros::delay(200);
	Intake.move_voltage(0);
	
	//first push
	chassis.setPose(8,-29,90);
	chassis.moveToPoint(20,-29,1000);
	chassis.setPose(20,-29,90);
	chassis.turnTo(46,-15,1000,false);
	pros::delay(700);
	wings.set_value(1);
	chassis.moveToPoint(60,-10,4000,false,80);
		Intake.move_voltage(12000);


	


}
}

void opcontrol()
{
	pros::Controller master(pros::E_CONTROLLER_MASTER);
if(selector::auton == skillsAuton){
	SkillsStartRoute();
	chassis.waitUntilDone();

}
	while (true)
	{

		chassis.tank(master.get_analog(ANALOG_LEFT_Y), master.get_analog(ANALOG_RIGHT_Y), 7);
		// wings
		if (master.get_digital_new_press(R1))
		{
			if (wingtoggle)
			{
				wings.set_value(1);
			}
			else
			{
				wings.set_value(0);
			}
			wingtoggle = !wingtoggle;
		}

		// lift
		if (master.get_digital_new_press(Up))
		{
			if (lifttoggle)
			{
				liftup.set_value(1);
				liftdown.set_value(0);
			}
			else
			{
				liftup.set_value(0);
				liftdown.set_value(1);
			}
			lifttoggle = !lifttoggle;
		}

		//fw
		if (master.get_digital_new_press(R2))
		{
			if (fwtoggle)
			{
		Kicker.move_voltage(11100*kickerSpeedPercentage);
			}
			else
			{
				Kicker.move_voltage(0);
			}
			fwtoggle = !fwtoggle;
		}
		// intake

		
		if (master.get_digital(L1))
		{
			Intake.move_voltage(-12000);
		}
		else if (master.get_digital(L2))
		{
			Intake.move_voltage(12000);
		}
		else
		{
			Intake.move_voltage(0);
		}

		// hang
		if (master.get_digital(Down))
		{
			hang.set_value(1);
		}
		pros::delay(20);
	}
}
