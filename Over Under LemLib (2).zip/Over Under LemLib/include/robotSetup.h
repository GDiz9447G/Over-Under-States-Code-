#pragma once
#include "main.h" // IWYU pragma: keep

//motors:
#define fwport 18
#define IMUPort 13
#define KickerPort 18
#define IntakePort 6
#define LiftUpPort 'g'
#define LiftDownPort 'f'
#define WingPort 'h'
#define HangPort 'e'
#define LeftDriveFront 8
#define LeftDriveBottom 9
#define LeftDriveTop 10
#define RightDriveFront 3
#define RightDriveBottom 2
#define RightDriveTop 4

//carts:
#define redCart pros::motor_gearset_e_t::E_MOTOR_GEARSET_36
#define greenCart pros::motor_gearset_e_t::E_MOTOR_GEARSET_18
#define blueCart pros::motor_gearset_e_t::E_MOTOR_GEARSET_06

//controller buttons: (from Rhett from 9623D)
#define L1 pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_L1
#define L2 pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_L2
#define R1 pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_R1
#define R2 pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_R2
#define A pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_A
#define B pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_B
#define X pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_X
#define Y pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_Y
#define Up pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_UP
#define Down pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_DOWN
#define Right pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_RIGHT
#define Left pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_LEFT
#define LeftX pros::controller_analog_e_t::E_CONTROLLER_ANALOG_LEFT_X
#define LeftY pros::controller_analog_e_t::E_CONTROLLER_ANALOG_LEFT_Y
#define RightX pros::controller_analog_e_t::E_CONTROLLER_ANALOG_RIGHT_X
#define RightY pros::controller_analog_e_t::E_CONTROLLER_ANALOG_RIGHT_Y

//other helpful definitions
#define elimsFarSideAuton 1
#define matchFarSideAuton 4
#define skillsAuton 3
#define closeSideAuton 2

static bool wingtoggle = true;
static bool lifttoggle = true; 
static bool hangtoggle = true; 
static bool intaketoggle = true;
static bool fwtoggle = true;